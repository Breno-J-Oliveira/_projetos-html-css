programa {
  funcao inicio() {
    real op, no1, no2, no3, media, mediacalculada
    op=0

    enquanto(op!=5) {
      escreva("Menu\n")
       escreva("\n 1.Solicitar notas")
       escreva("\n 2.Média")
       escreva("\n 3.Exibir situação")
       escreva("\n 4.Modificar notas")
       escreva("\n 5.Sair\n")
       leia(op)

       escolha(op){
        caso 1:
        escreva("\nInsira suas notas\n")
        escreva("\nInsira sua primeira nota\n")
        leia(no1)
        escreva("\nInsira sua segunda nota\n")
        leia(no2)
        escreva("\nInsira sua terceira nota\n")
        leia(no3)
        media= (no1+no2+no3)/3
        mediacalculada= 1
        pare

        caso 2:
        se(mediacalculada>0) {
          escreva("\nSua média é igual à ", media)
          se(media>6) {
            escreva("\n Você passou\n")
          }
          senao{
            escreva("\nVocê não passou")
          }
        }
        senao{
          escreva("\nVocê não insiriu suas notas")
        }
        pare

        caso 3:
        se(mediacalculada>0){
             se(media>6){
          escreva("\nVocê passou de ano", media)
        }
        senao{
          escreva("\nVocê não pssou por sua média ser ", media)
        }
        }
        senao{
          escreva("\nVocê não colocou suas notas\n")
        }
        pare

        caso 4:
        escreva("\ninsira sua primeira nota\n")
        leia(no1)
        escreva("\nInsira sua segunda nota\n")
        leia(no2)
        escreva("\ninsira sua terceira nota\n")
        leia(no3)
        pare
       
       caso contrario:
       escreva("\nOpção invalida\n")
       pare

       }
    }
  }
}
